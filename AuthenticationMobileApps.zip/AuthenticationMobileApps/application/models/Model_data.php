<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
class Model_data extends CI_Model{
	
	
	function get_data() {
		return $this->db->get('finger')->result_array();
	}
	function get(){
		$nip = $this->db->get('finger');
		return $nip;
	}
	
	//absen mobile by nip
	function take_absen_m_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir){
			return $this->db->query("select id, nip, latitude, longitude, presensi_ke, photo, macaddress, created_at 
									from absen_mobile 
									where nip='".$nip."' AND date(created_at) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
									"' ORDER BY created_at DESC")->result();
	}

	//absen mobile all
	function take_absen_all_m_between_tgl($tgl_awal,$tgl_akhir){
			return $this->db->query("select id, nip, latitude, longitude, presensi_ke, photo, macaddress, created_at 
									from absen_mobile 
									where date(created_at) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
									"' ORDER BY created_at DESC")->result();
	}

	//absen per unit
	function take_absen_unit($tgl_awal,$tgl_akhir,$unit){
		$this->db->select('a.finger_id, b.nip,a.tag_date,a.finger_ip');
		$this->db->from('absen_finger as a');
		$this->db->join('finger as b','a.finger_id=b.finger_id');
		$this->db->where('a.finger_ip',$unit);
		$this->db->order_by('a.tag_date', 'DESC');
		return $this->db->get()->result();

	}

	//fingerprint method (absen finger per nip)
	function take_absen_f_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir){
		return $this->db->query("select DISTINCT a.finger_id, b.nip,a.tag_date,a.finger_ip 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.finger_id
								 where b.nip='".$nip."' AND date(a.tag_date) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
								 "' ORDER BY a.tag_date ASC")->result();
// return $this->db->query("select id, nama, finger_id, tag_date,  finger_ip
// 									from absen_finger")->result();
	}

	//fingerprint method (absen finger all)
	function take_absen_all_f_between_tgl($tgl_awal,$tgl_akhir){
		return $this->db->query("select a.finger_id, b.nip,a.tag_date,a.finger_ip 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.finger_id
								 where date(a.tag_date) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
								 "' ORDER BY a.tag_date DESC")->result();
	}

	// method for pegawai pribadi
	function absPegawaiMobile($nip,$tgl_awal,$tgl_akhir,$offset,$limit){
			return $this->db->query("select nip, latitude, longitude, photo, macaddress, created_at 
									from absen_mobile 
									where nip='".$nip."' AND date(created_at) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
									"' ORDER BY created_at DESC LIMIT ".$limit." OFFSET ".$offset)->result();
	}

	// method for pegawai unit
	function absPegawaiMobileUnit($tgl_awal,$tgl_akhir,$offset,$limit){
			return $this->db->query("select nip, latitude, longitude, photo, macaddress, created_at 
									from absen_mobile 
									where date(created_at) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
									"' ORDER BY created_at DESC LIMIT ".$limit." OFFSET ".$offset)->result();
	}

	//fingerprint method
	function absPegawaiFinger($nip,$tgl_awal,$tgl_akhir,$offset,$limit){
		return $this->db->query("select b.nip,a.tag_date,a.finger_ip 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.no_finger
								 where b.nip='".$nip."' AND date(a.tag_date) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
								 "' ORDER BY a.tag_date DESC LIMIT ".$limit." OFFSET ".$offset)->result();
	}

	//fingerprint method unit
	function absPegawaiFingerUnit($tgl_awal,$tgl_akhir,$offset,$limit){
		return $this->db->query("select b.nip,a.tag_date,a.finger_ip 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.no_finger
								 where date(a.tag_date) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
								 "' ORDER BY a.tag_date DESC LIMIT ".$limit." OFFSET ".$offset)->result();
	}

	function presensiKe($tanggal,$nip){
		return $this->db->query("select COUNT(id) as jmlh from absen_mobile where nip='".$nip."' AND to_char(created_at,'YYYY-MM-DD')='".$tanggal."'")->result();
	}

	//insert_absen_mobile
	function insert_data_mobile($data=array()){
		$value=array(
			   'nip'       => $data['nip'],
			   'latitude'  => $data['latitude'],
			   'longitude' => $data['longitude'],
			   'photo'	   => $data['photo'],
			   'macaddress'=> $data['macaddress'],
			   'created_at'=> $data['created_at'],
			   'presensi_ke'=>$data['presensi_ke']);
		$this->db->insert('absen_mobile',$value);
	}

	//insert_absen_sanggah
	function insert_data_sanggah($data=array()){
		$value=array(
			'finger_id' => $data['id'],
			'nip'  		=> $data['nip'],
			'presensi_ke'=> $data['presensi_ke'],
			'tag_date'	=> $data['tag_date'],
  	 		'ket'		=> $data['ket']
  	 		);
		$this->db->set('tgl_diajukan', 'NOW()', FALSE);
		$this->db->insert('absen_sanggah',$value);
	}
	
	//sanggah method
	function sanggahAbs($nip){
		return $this->db->query("select presensi_ke,tag_date,tgl_diajukan,ket,status from absen_sanggah where nip='".$nip."'
		order by tgl_diajukan DESC")->result();
	}

	//finger){
	// 	$value = array(
	// 	'nama' => $data['nama'] ,
	// 	'finger_id' => $data['fingerId'] ,
	// 	'tag_date'  => $data['tag_date'] ,
	// 	'finger_ip' => $data['ip']);
	// 	$this->db->insert('absen_finger',$value);
	// }

	function insert_data_finger($data=array()){
		$value = array('nama' => $data['nama'] ,
					 	'finger_id' => $data['fingerId'] ,
				       'tag_date'  => $data['tag_date'] ,
				       'finger_ip' => $data['ip']
				 );
		$this->db->insert('absen_finger',$value);
	}

	//insert user finger
	function insert_user_finger($data=array()){
		$value = array(	'finger_id' => $data['fingerId'] ,
						'no_finger' => $data['no_finger']
					 	
				 );
		$this->db->insert('finger',$value);
	}

	//mobile method
	
	function take_absen_all_m(){
		return $this->db->query('select * from absen_mobile')->result();
	}
	
	function take_absen_m_by_nip($nip){
			return $this->db->query("select * from absen_mobile where nip=".$nip)->result();
	}
	

	/*
	function take_absen_m_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir){insert_data_finger
			return $this->db->query("select nip, latitude, longitude, photo, macaddress, created_at 
									from absen_mobile 
									where nip='".$nip."' AND date(created_at) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
									"' ORDER BY created_at ASC")->result();
	}

	*/
	function take_absen_m_by_nip_tgl($nip,$tgl){
			return $this->db->query("select * from absen_mobile where nip=".$nip." AND date(created__at)='".$tgl."' ORDERBY created_at ASC")->result();
	}

	function take_absen_m_by_nip_bln($nip,$bln){
			return $this->db->query("select * 
									from absen_mobile 
									where nip=".$nip." AND Extract(MONTH FROM created_at)=".$bln.
									" ORDERBY created_at ASC")->result();
	}
	

	//fingerprint method
	/*
	function take_absen_f_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir){
		return $this->db->query("select b.nip,a.tag_date,a.finger_ip 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.finger_id
								 where b.nip='".$nip."' AND date(a.tag_date) BETWEEN '".$tgl_awal."' AND '".$tgl_akhir.
								 "' ORDER BY a.tag_date ASC")->result();
	}

	function insert_data_mobile($data=array()){
		$value=array(
			   'nip'       => $data['nip'],
			   'latitude'  => $data['latitude'],
			   'longitude' => $data['longitude'],
			   'photo'	   => $data['photo'],
			   'macaddress'=> $data['macaddress'],
			   'created_at'=> $data['created_at']);
		$this->db->insert('absen_mobile',$value);
	}
*/	
	function update_data_mobile($data=array(),$nip){
		$value=array(
			   'latitude'  => $data['latitude'],
			   'longitude' => $data['longitude'],
			   'photo'	   => $data['photo'],
			   'macaddress'=> $data['macaddress'],
			   'created_at'=> $data['created_at']);
		$this->db->where('nip',$nip);
		$this->db->update('absen_mobile',$value);
	}

	function delete_data_mobile($nip){
		$value= array('nip' => $nip);
		$this->db->delete('absen_mobile',$value);
	}

	function take_absen_all_f(){
		return $this->db->query('select a.*,b.no_finger,b.nip,b.created_date,b.end_date 
								 from absen_finger as a
								 inner join finger as b
								 on a.finger_id=b.finger_id')->result();
	}
	//----------------------------------------------------------------------------------
	
	function take_data_absen_mobile3(){
		$query = $this->db->query('select * from absen_mobile')->result();
		foreach ($query as $row) {
			json_encode($row);
		}
		return $row;
	}

	// //Relasi Data Finger
	// function relasiDataFinger($no_finger,$finger_id){
	// 	return $this->db->query('select * no_finger from absen_finger
	// 							 inner join finger on finger_id
	// 							 where no_finger = ".$no_finger."
	// 							 AND finger_id=.".$finger_id."')->result();
	// }

	//Relasi Data Finger
	function relasi_data_finger(){
		return $this->db->query("select finger_id, no_finger, nip, created_date, end_date 
								 from finger")->result();
	}
	
//insert_relasi
	function insert_relasi($data=array()){
		$value=array(
			'finger_id' 	=> $data['id'],
			'no_finger' 	=> $data['no'],
			'nip'  		    => $data['nip'],
			'created_date'	=> $data['created_date'],
  	 		'end_date'		=> $data['end_date']
  	 		);
		$this->db->set('created_date', 'NOW()', FALSE);
		$this->db->insert('finger',$value);
	}
	//finger
/*	 
	function insert_data_finger($data=array()){
		$value = array('finger_id' => $data['fingerId'] ,
				       'tag_date'  => $data['tag_date'] ,
				       'finger_ip' => $data['ip']
				 );
		$this->db->insert('absen_finger',$value);
	}
*/
	function test(){
		return $this->db->query("select * from absen_mobile")->result();
	}
}