<?php
$username   = $_POST['username'];
$password   = $_POST['password'];

$sql    = "SELECT * FROM login WHERE username='$username' AND password='$password'";

$query  = mysql_query($sql);

if (mysql_num_rows($query) > 0 ) {
    echo "Sukses";
}else{
    echo "Gagal";
    exit();
}