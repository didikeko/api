<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<!-- meta name="robots" content="index,follow" -->
	<meta name="robots" content="noindex,nofollow">
	<title>Relasi</title>
	<link href="http://akademik.uin-suka.ac.id/asset/img/favicon.png" type="image/x-icon" rel="shortcut icon">
	<link href="http://akademik.uin-suka.ac.id/asset/css/style_global.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/style_sp_akademik.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/style.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/style_sp_post.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/style_hack.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/dynatree/dynatree.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/jquery.jqplot.min.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/redactor.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/docs.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/css_ui.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css">
	<link href="http://akademik.uin-suka.ac.id/asset/css/progtracker.css" rel="stylesheet" type="text/css">
	<style type="text/css">
		table.table-user { border: none; border-top: 1px solid #DDD; width: 100%; }
		table.table-user tr td { padding: 5px; border-top: 1px solid #DDD; border-right: 0px solid #DDD; border-left: 1px solid #DDD; }
		table.table-user tr:last-child td { border-bottom: 1px solid #DDD; }
		table.table-user tr td:last-child { border-right: 1px solid #DDD; }
		table.table-user tr td.snippet-label { width: 125px; font-weight: bold; background: #EEE; border-top: 1px solid #DDD; }
		table.table-user tr td.snippet-label2 { width: 85px; font-weight: bold; background: #EEE; border-top: 1px solid #DDD; }
		table.table-user tr:first-child td.snippet-label { border-top: none; }
		
		table.table-snippet tr td.snippet-label { width: 150px; font-weight: bold;  }
		table.table-snippet tr td { padding: 2px; }
		a.link { text-decoration: underline; }
	</style>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>	
</head>
<body cz-shortcut-listen="true">
<div class="sia-basic_header-top"></div>
<div class="sia-basic_main-full">
	<div style="max-width:980px; margin: 0 auto;">
	<div class="sia-basic_header-app">
		<div class="sia-basic_header-app-id-uin">
			<a href="http://akademik.uin-suka.ac.id/" style="display: block; width: 300px; height: 80px; background:none;"></a>
		</div>
		<div class="sia-basic_header-app-id-rightcontent">
			<div class="sia-basic_header-app-id-app">Sistem Informasi Akademik</div>
			<div class="sia-basic_header-app-id-unv">UIN Sunan Kalijaga</div>
		</div>
		<div class="clear"></div>
	</div>
	</div>
</div>
<div class="sia-basic_main">
	<div id="sidebar-sia">
		
	</div>
	<div id="content">
		<div id="system-content-sia">
			<table class="table table-nama" style="border: none; margin-bottom:2%;">
				<tbody>
				<tr><td class="table-nama-id">NIP.</td>
				<td>: <?php echo $_SESSION['nip'];?></td></tr>
				
				<tr><td class="table-nama-id">Nama Pegawai</td>
				<td>: <?php echo $_SESSION['nama'];?></td></tr>
				
				<tr><td class="table-nama-id">Instansi</td>
				<td>: Instansi</td></tr>

				<tr><td class="table-nama-id" style="width:175px;">Terakhir Login</td>
				<td>: 
				log Login
				</td></tr>
				
				</tbody>
			</table>
			<ul id="crumbs"><li><a href="#" title="Perkuliahan">Presensi</a></li><li>Relasi</li></ul>
			<br>
			<center><img id="loader" src="images/ajax-loader.gif"></center>

	<!--======================FORM==================================-->
	<form class="form-inline" id="date" method="get" action="http://service2.uin-suka.ac.id/presensi/relasi">
		<div class="table-responsive" id="tabelku">
			<table id="tableform" class="table table-bordered table-hover">
				<tr class="header-table">
					<td>No.</td>
					<td>Id Fingerprint</td>
					<td>Nama</td>
					<td>NIP Pegawai</td>
					<td>Tanggal Mulai</td>
					<td>Tanggal Selesai</td>
					<td>Aksi</td>
				</tr>
				<tr>
					<td>1</td>
					<td><input type="" name="" value="14031"></td>
					<td>Agung Fatwanto Ph.D</td>
					<td><input type="" name="" value="197701032005011003"></td>
					<td><input type="text" class="form-control datepicker input-sm" id="tgs" name="tgs" value='2005-01-01'></td>
					<td><input type="text" class="form-control datepicker input-sm" id="tge" name="tge" value='2017-01-01'></td>
					<td><input type="submit" id="simpan" onclick="simpanData()" value="Simpan" class="btn btn-small"></td>
				</tr>
			</table>
		</div>
	</form>
	<!--======================FORM==================================-->
	<!--======================TABEL==================================-->
	<form class="form-inline" id="date" method="get" action="http://service2.uin-suka.ac.id/presensi/relasi">
		<div class="table-responsive" id="tabelku">
			<table id="tableform" class="table table-bordered table-hover">
				<tr class="header-table">
					<td>No.</td>
					<td>Id Fingerprint</td>
					<td>Nama</td>
					<td>NIP Pegawai</td>
					<td>Tanggal Mulai</td>
					<td>Tanggal Selesai</td>
					<td>Aksi</td>
				</tr>
				<tr>
					<td>1</td>
					<td>14031</td>
					<td>Agung Fatwanto Ph.D</td>
					<td>197701032005011003</td>
					<td>2005-01-01</td>
					<td>2017-01-01</td>
					<td><input type="submit" id="edit" onclick="simpanData()" value="Edit" class="btn btn-small"></td>
				</tr>
			</table>
		</div>
	</form>
	<!--======================TABEL==================================-->
</div>
</body>
<script>
	$(function() {
		//datepicker jquery UI
		$( ".datepicker" ).datepicker({ dateFormat: "yy-mm-dd" }).val();
		//hiding loader
		$("#loader").hide();
		//hiding dialog
		$.ui.dialog.prototype._focusTabbable = $.noop;
		$('#dialog').dialog({
		    autoOpen: false,
		    height:400,
		    width:700
		});
	});

	//event prevent submiting
	$( "#date" ).submit(function( event ) {
	  event.preventDefault();
	}); 

	// ajax get function 
	function simpanData(){
		//inisiasi variable
		var form   = $("#date"),
	    	tgsval = form.find( "input[name='tgs']" ).val(),
	    	tgeval = form.find( "input[name='tge']" ).val(),
	    	url    = form.attr( "action" );

		$("#tabelku" ).empty();
	  	$("#loader").show();
	  	$("#submit").attr("disabled",true);
	  // Send the data using post
	  var getData = $.get( url, {tgs : tgsval, tge : tgeval, ajax : true });
	  getData.done(function( data ) {
  		var content = $( data );
    	$("#loader").hide();
    	$("#tabelku" ).append(content);
    	$("#submit").attr("disabled",false);
	  });
	}
</script>
</html>