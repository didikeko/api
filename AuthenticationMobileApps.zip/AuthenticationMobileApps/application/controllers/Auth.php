<?php
/**
 * Creator: Raka Adi Nugroho
 * Mail: nugrohoraka@gmail.com
 * Date: 1/20/17
 * Time: 10:47 AM
 */
class Auth extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
    }
    public function haha(){
        header('Content-Type: application/json');
        $unit_id = 'UN02006'; //SAINTEK
        $kd_penandatangan_surat = '76'; #Kepala Bagian Tata Usaha
        $kode_klasifikasi = 'KM.00.4'; #'LAPORAN STATUS MAHASISWA', untuk status aktif studi
        #$kode_klasifikasi = 'KS.02'; #'KETATAUSAHAAN', #penggantian ktm
        $kode_jenis_surat = '11'; #'SURAT KETERANGAN'
        
        $data_sk['UNIT_ID']                 = $unit_id;
        $data_sk['KD_STATUS_SIMPAN']        = 2;
        $data_sk['ID_PSD']                  = $kd_penandatangan_surat;
        $data_sk['ID_KLASIFIKASI_SURAT']    = $kode_klasifikasi;
        $data_sk['KD_JENIS_SURAT']          = $kode_jenis_surat;
        $data_sk['KD_KEAMANAN_SURAT']       = 'B';
        $data_sk['TGL_SURAT']               = date('d/m/Y');


        $data_sk    = "15380043";
        $sekarang   = DATE('d-m-y');
        $par1   = array($data_sk);
        $datar = $this->siaapi_getnomor('tnde_public/tnde_surat_keluar/penomoran/json',90002,3,'api_search',$par1);
        $datrr = json_decode($datar,true);
        echo json_encode($datrr);
    }
    public function testing()
    {
        //header('Content-Type: application/json');
        $user   = '15650051';
        $pass   = 'marimenghafalalquran';
        $auth_ad_id = '8f304662ebfee3932f2e810aa8fb628735';
        $api_url 	= 'http://service.uin-suka.ac.id/servad/adlogauthgr.php?aud='.$auth_ad_id.'&uss='.$user.'&pss='.$pass;
        $hasil = file_get_contents($api_url);
        // var_dump($hasil);
        //  die();
        $hasil = json_decode($hasil, true);
        echo json_encode($hasil,JSON_PRETTY_PRINT);
    }
    public function mobileauth()
    {
        header('Content-Type: application/json');
        $username   = $this->input->post('username');
        $password   = $this->input->post('password');
        #$username   = '197701032005011003';
        #$password   = '19770103';
        $result     = $this->logincheck($username, $password);
        $response   = array();
        if (is_array($result)){
//            if ($result[0]['AnggotaDari'][0][0] == "StaffGroup"){
            if (in_array("StaffGroup", $result[0]['AnggotaDari'][0])){
                if ($this->checkjabatanlogin($result[0]['NamaPengguna'])){
                    $fotoparameter  = "foto/pgw/980/".$this->cekaje("FOTOAUTO#".$result[0]['NamaPengguna']."#QL:80#WM:1#SZ:120").".jpg";
                    $response = array(
                        'status'    => true,
                        'message'  => 'Authentication Success',
                        'auth'      => array(
                            'nip'   => $result[0]['NamaPengguna'],
                            'nama_lengkap'  => $this->checkdetail($result[0]['NamaPengguna']),
//                            'level' => $result[0]['AnggotaDari'][0][0],
                            'level' => "StaffGroup",
                            'foto' => $this->generatorinaje($fotoparameter)
                        )
                    );
                }else{
                    $response = array(
                        'status'    => false,
                        'message'  => 'Gagal, Aplikasi Untuk Dosen'
                    );
                }
            }else{
                $response = array(
                    'status'    => false,
                    'message'  => 'Gagal, Anda Bukan Pegawai'
                );
            }
        }else{
            $response = array(
                'status'    => false,
                'message'  => $this->checkmessages($result)
            );
        }
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
    public function logincheck($user, $pass)
    {
        #$user   = '197701032005011003';
        #$pass   = '19770103';
        header('Content-Type: application/json');
        $auth_ad_id = '8f304662ebfee3932f2e810aa8fb628722';
        $api_url 	= 'http://service.uin-suka.ac.id/servad/adlogauthgr.php?aud='.$auth_ad_id.'&uss='.$user.'&pss='.$pass;
        $hasil = file_get_contents($api_url);
        $hasil = json_decode($hasil, true);
        return $hasil;
    }

    public function testlogin(){
        $user   = '197701032005011003';
        $pass   = '19770103';
        var_dump($this->logincheck($user,$pass));

    }
    public function checkjabatanlogin($nip){
        $allowed    = ['Asisten Ahli', 'Lektor','Lektor Kepala', 'Guru Besar'];
        if (in_array($this->checkjabatanfungsional($nip), $allowed)){
            return true;
        }else{
            return false;
        }
    }
    public function checkanggotaunit(){
        header('Content-Type: application/json');
        $unitid = $this->input->get("unitid");
        $parameter  = array($unitid);
//        $parameter  = array("UN01028");
        $datar = $this->siaapi_getdata('simpeg_public/simpeg_mix/data_search',1121,15,'api_search',$parameter);
        $datrr = json_decode($datar,true);

        $result = array();
        foreach ($datrr as $value){
            array_push($result, array(
                'nip'   => $value['NIP'],
                'nama'  => $value['NM_PGW_F']
            ));
        }
        echo json_encode($result, JSON_PRETTY_PRINT);
    }
    public function checkdaftarunit(){
        header('Content-Type: application/json');
        $datar = $this->siaapi_getdata('simpeg_public/simpeg_mix/data_view',1001,3, null ,null);
        $datrr = json_decode($datar,true);
        $result = array();
        foreach ($datrr as $value){
            array_push($result, array(
                'unit_id'   => $value['UNIT_ID'],
                'unit_nama' => $value['UNIT_NAMA']
            ));
        }
        echo json_encode($result, JSON_PRETTY_PRINT);
    }
    public function checkdetail($nip)
    {
        $par1 = array($nip);
        $datar = $this->siaapi_getdata('simpeg_public/simpeg_mix/data_search',2001,2,'api_search',$par1);
        $datrr = json_decode($datar,true);
        return $datrr[0]['NM_PGW_F'];
    }
    public function checkjabatanfungsional($nip){
        $nip    = "195505011998121002";
        $sekarang   = DATE('d-m-y');
        $par1   = array($sekarang, $nip, 1);
        $datar = $this->siaapi_getdata('simpeg_public/simpeg_mix/data_search',1122,3,'api_search',$par1);
        $datrr = json_decode($datar,true);
        var_dump($datrr);
        //return $datrr[0]['FUN_NAMA'];
    }
    public function carimhs(){
        header('Content-Type: application/json');
        $nim    = "15380043";
        $sekarang   = DATE('d-m-y');
        $par1   = array($nim);
        $datar = $this->siaapi_getmhs('sia_public/sia_mahasiswa/data_search',26000,10,'api_search',$par1);
        $datrr = json_decode($datar,true);
        echo json_encode($datrr);
    }
    function siaapi_getmhs($apiurl=null,$apikod=0,$apisub=0,$apitxt=null,$apisrc=array()){
        $aipisp = 'http://service.uin-suka.ac.id/';
        $ch = curl_init();
        $URL_API = $aipisp.'servsiasuper/'.$apiurl;
        $data = array('api_kode' => $apikod, 'api_subkode' => $apisub, $apitxt => $apisrc);
        curl_setopt($ch, CURLOPT_URL, $URL_API);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('HeaderName: '.hash('sha256','tester01')));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        return $result;
    }
    function siaapi_getnomor($apiurl=null,$apikod=0,$apisub=0,$apitxt=null,$apisrc=array()){
        $aipisp = 'http://service2.uin-suka.ac.id/';
        $ch = curl_init();
        $URL_API = $aipisp.'servtnde/'.$apiurl;
        $data = array('api_kode' => $apikod, 'api_subkode' => $apisub, $apitxt => $apisrc);
        curl_setopt($ch, CURLOPT_URL, $URL_API);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('HeaderName: '.hash('sha256','tester01')));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        return $result;
    }
    function siaapi_getdata($apiurl=null,$apikod=0,$apisub=0,$apitxt=null,$apisrc=array()){
        $aipisp = 'http://service2.uin-suka.ac.id/';
        $ch = curl_init();
        $URL_API = $aipisp.'servsimpeg/'.$apiurl;
        $data = array('api_kode' => $apikod, 'api_subkode' => $apisub, $apitxt => $apisrc);
        curl_setopt($ch, CURLOPT_URL, $URL_API);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('HeaderName: '.hash('sha256','tester01')));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        return $result;
    }

    public function postCURL($_url, $_param){

        $postData = '';
        foreach($_param as $k => $v)
        {
            $postData .= $k . '='.$v.'&';
        }
        rtrim($postData, '&');


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

        $output=curl_exec($ch);

        curl_close($ch);

        return $output;
    }
    public function testsaja(){
        $nim = "14650015";
        $prams  = array(
                        'api_kode'      => 26000,
                        'api_subkode'   => 10,
                        'api_search'    => array($nim)
                    );

        $hasil = $this->postCURL("http://service.uin-suka.ac.id/servsiasuper/sia_public/sia_mahasiswa/data_search", $prams);

        var_dump($hasil);
    }
    function api_curl($url,$post,$method){
        $username="12792860";
        $password="4908773573895678";
        //////////////
        if(strtoupper($method)=='POST'){
            $postdata = http_build_query($post);
            $opts = array('http' =>
                array(
                    'method'  => 'POST',
                    'header' => 'Content-type: application/x-www-form-urlencoded' . "\r\n"
                        .'Content-Length: ' . strlen($postdata) . "\r\n",
                    'content' => $postdata
                )
            );
            if($username && $password)
            {
                $opts['http']['header'] = ("Authorization: Basic " . base64_encode("$username:$password"));
            }

            $context = stream_context_create($opts);
            $hasil=file_get_contents($url, false, $context);
            return $hasil;
        }else{
            foreach($post as $key=>$value){
                $isi=$isi."/".$key."/$value/";
            }
            $url=$url.$isi;
            $context = stream_context_create(array(
                'http' => array(
                    'header'  => "Authorization: Basic " . base64_encode("$username:$password")
                )
            ));
            #echo "<p>$url</p>";
            $hasil=file_get_contents($url, false, $context);
            return $hasil;
        }
    }
    private function checkmessages($errorcode)
    {
        $messages   = null;
        switch ($errorcode){
            case 1:
                $messages   = "IP tidak diijinkan";
                break;
            case 2:
                $messages   = "Terjadi Kesalahan Autentikasi";
                break;
            case 3:
                $messages   = "Tidak Bisa Konek Keserver";
                break;
            case 4:
                $messages   = "Username atau Password Salah";
                break;
            case 5:
                $messages   = "Kesalahan Data";
                break;
            case 6:
                $messages   = "Data Kosong";
                break;
        }
        return $messages;
    }

    private function tg_encode($kd_kelas)
    { 
        $hasil = ''; #return $kd_kelas;
        $str    = 'sng3bAdac5UEmQzv2YBTH8CVh7jXpRo0etfOK4MINSlwFZ6iL9kPD1JWyuqGxr#-.:/';
        $arr_e = array();  $arr_e1 = array(); $arr_r = array(); $arr_r1 = array();
        for($j = 0; $j < strlen($str); $j++){
            $j_ = $j; if ($j_ < 10) { $j_ = '0'.$j_; }
            $arr_e1[$j] = substr($str,$j,1);
            $arr_e[$j_] = substr($str,$j,1);
            $arr_r1[substr($str,$j,1)] = $j;
            $arr_r[substr($str,$j,1)] = $j_;
        }
        $total = 0;
        for($i = 0; $i < strlen($kd_kelas); $i++){
            $total = (int)substr($kd_kelas,$i,1) + $total; 
        } $u = fmod($total,10);
        $kd_enc = $arr_e1[$u];
        for($i = 0; $i < strlen($kd_kelas); $i++){
            $k = ($arr_r1[substr($kd_kelas,$i,1)]+$u); if($k < 10) { $k = '0'.$k; }
            $kd_enc .= ''.$k.rand(0,9); 
        } return $kd_enc;
    }

    function cekaje($kd_kelas){
        $hasil = ''; #return $kd_kelas;
        $str 	= 'sng3bAdac5UEmQzv2YBTH8CVh7jXpRo0etfOK4MINSlwFZ6iL9kPD1JWyuqGxr#-.:/';
        $arr_e = array();  $arr_e1 = array(); $arr_r = array(); $arr_r1 = array();
        for($j = 0; $j < strlen($str); $j++){
            $j_ = $j; if ($j_ < 10) { $j_ = '0'.$j_; }
            $arr_e1[$j] = substr($str,$j,1);
            $arr_e[$j_] = substr($str,$j,1);
            $arr_r1[substr($str,$j,1)] = $j;
            $arr_r[substr($str,$j,1)] = $j_;
        }
        $total = 0;
        for($i = 0; $i < strlen($kd_kelas); $i++){
            $total = (int)substr($kd_kelas,$i,1) + $total;
        } $u = fmod($total,10);
        $kd_enc = $arr_e1[$u];
        for($i = 0; $i < strlen($kd_kelas); $i++){
            $k = ($arr_r1[substr($kd_kelas,$i,1)]+$u); if($k < 10) { $k = '0'.$k; }
            $kd_enc .= ''.$k.rand(0,9);
        } return $kd_enc;
    }
    public function testaje()
    {
        $user   = '196612091994031004';
        $fotoparameter  = "foto/pgw/980/".$this->cekaje("FOTOAUTO#".$user."#QL:80#WM:1#SZ:120").".jpg";
        echo $this->generatorinaje($fotoparameter);
    }
    private function generatorinaje($encresult)
    {
        $baseurl    = "aHR0cDovL3N0YXRpYy51aW4tc3VrYS5hYy5pZC8=";
        $result     = base64_decode($baseurl).$encresult;
        return $result;
    }
}