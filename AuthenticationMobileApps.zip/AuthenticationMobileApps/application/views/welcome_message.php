<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	table{
		width: 100%;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	td{
		border: 1px solid #D0D0D0;
		padding: 5px;
	}
	code{
		color:white;
		background-color:#665e5e; 
	}
	input[type="text"]{
		margin-top: 3px;
		margin-bottom: 3px;
	}
	</style>
</head>
<body>

<div id="container">
	<h1>DOKUMENTASI CARA MEMAKAI API UNTUK LATIHAN API SEMENTARA TUGAS RPL</h1>

	<div id="body">

		<p>API GET DAPAT DI AKSES PADA URL DIBAWAH INI</p>
		<code>http://service2.uin-suka.ac.id/api/absen?nip=..&tgs=..&tge=..</code>
		<table>
			<tr>
				<th>PARAMETER</th>
				<th>FORMAT</th>
				<th>KETERANGAN</th>
			</tr>
			<tr>
				<td>NIP</td>
				<td>NUMBER</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>TGS</td>
				<td>YYYY-MM-DD</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>TGE</td>
				<td>YYYY-MM-DD</td>
				<td>REQUIRED</td>
			</tr>
		</table>
			<br>
		<p>API POST UPLOAD GAMBAR DAPAT DI AKSES PADA URL DIBAWAH INI method post, multipart:file</p>
		<code>http://service2.uin-suka.ac.id/api/uppic</code>
		<table >
			<tr>
				<th>ID KEY</th>
				<th>FORMAT</th>
				<th>KETERANGAN</th>
			</tr>
			<tr>
				<td>nip</td>
				<td>NUMBER</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>photo</td>
				<td>file: jpg or png</td>
				<td>REQUIRED</td>
			</tr>
		</table>
		<br>		
		<p>API POST DAPAT DI AKSES PADA URL DIBAWAH INI</p>
		<code>http://service2.uin-suka.ac.id/api/absen</code>
		<table >
			<tr>
				<th>ID KEY</th>
				<th>FORMAT</th>
				<th>KETERANGAN</th>
			</tr>
			<tr>
				<td>nip</td>
				<td>NUMBER</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>latitude</td>
				<td>LONGLAT FORMAT</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>longitude</td>
				<td>LONGLAT FORMAT</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>photo</td>
				<td>[directory] response from http://service2.uin-suka.ac.id/api/uppic</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>macaddress</td>
				<td>MACADDRESS</td>
				<td>REQUIRED</td>
			</tr>
			<tr>
				<td>created_at</td>
				<td>yyyy-mm-dd hh:mm:ss</td>
				<td>REQUIRED</td>
			</tr>
		</table>		
	</div>
	<div id="body">
		<table>
			<tr>
				<td style="text-align:center">
					<p>TEST API POST</p><br>
					<form action="api/absen" method="POST">
						<input type="text" id='nip' name="nip" placeholder="nip"><br>
						<input type="text" id='latitude' name="latitude" placeholder="77.223946"><br>
						<input type="text" id='longitude' name="longitude" placeholder="10.298939"><br>
						<input type="text" id='photo' name="photo" placeholder="url/photo"><br>
						<input type="text" id='macaddress' name="macaddress" placeholder="FE:BA:93:20"><br>
						<input type="text" id='created_at' name="created_at" placeholder="yyyy-mm-dd hh:mm:ss"><br><br>
						<input type="submit">
					</form>
				</td>
				<td style="text-align:center">
					TEST API POST UPLOAD<br>
					<form method="post" action="api/uppic" enctype="multipart/form-data" />
						<input type="text" name="nip"/ placeholder="nip"><br>
						<input type="file" name="photo" size="20"/>
						<br><br>
						<input type="submit" value="upload"/>

					</form>
				</td>
			</tr>
		</table>
	</div>

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>

</body>
</html>