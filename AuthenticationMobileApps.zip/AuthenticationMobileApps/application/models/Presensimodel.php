<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
class PresensiModel extends CI_Model{

	function getLocations($lat,$lon){
		$url="http://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lon&sensor=false";
		$opts = array(
				  'http'=>array(
				    'method'=>"GET",
				    'header'=>"Content-type: application/json"
				  )
				);
		$context = stream_context_create($opts);
		$result=file_get_contents($url,false,$context);
		$string=json_decode($result);
		if ($string->status=='OK') {
			return $string->results{0}->formatted_address;
		}else{
			return "undifinied location";
		}
		
	}
	function testgmbr($gbr){
			if ($gbr=="null") {
				return "no pic";
			}else{
				return "<img style='width:50px;height:50px' src='".$gbr."'>";
			}
	}
	function getJsondata($url){
			$opts = array(
			  'http'=>array(
			    'method'=>"GET",
			    'header'=>"Content-type: application/json"
			  )
			);
			$context = stream_context_create($opts);
			$string  =file_get_contents($url,false,$context);
			$result  =json_decode($string);
			return $result;
	}

	function postJsondata($url,$data){
			$opts = array(
			    'http' => array (
            	'method' => 'POST',
                'header'=> "Content-type: application/x-www-form-urlencoded\r\n",
            	'content' => http_build_query($data)
			  )
			);
			$context = stream_context_create($opts);
			$string=file_get_contents($url,false,$context);
			$result=json_decode($string);
			return $result;
	}

	function getcURL($url){
			$ch=curl_init();
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));

			$result=curl_exec($ch);
			curl_close($ch);
			$result=json_decode($result);
			return $result;
	}

	function postcURL($url,$data){
		$data=http_build_query($data);
		$ch=curl_init();
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/x-www-form-urlencoded'));

		$result=curl_exec($ch);
		curl_close($ch);
		$result=json_decode($result);
		return $result;
	}
	
	function indexWaktu($time){
		$timenumb=(int)str_replace(":","", $time);
		if ($timenumb>120000) {
			return 2;
		}else{
			return 1;
		}
	}

	function getUnit($ip){
		$allip=array(
					'10.10.28.129'=>'Adab',
					'10.10.28.130'=>'Dakwah',
					'10.10.28.131'=>'Syariah',
					'10.10.28.132'=>'Tarbiyyah',
					'10.10.28.133'=>'Ushulluddin',
					'10.10.28.134'=>'Soshum',
					'10.10.28.135'=>'Saintek',
					'10.10.28.136'=>'Rektorat',
					'10.10.28.137'=>'UPT Perspustakaan',
					'10.10.28.138'=>'Pusat Studi',
					'10.10.28.139'=>'PKSI',
					'10.10.28.140'=>'Pusat Bahasa',
					'10.10.28.141'=>'Pascasarjana',
					'10.10.28.142'=>'Poliklinik',
					'10.10.28.143'=>'Lab. Terpadu',
					'10.10.28.145'=>'Pimpinan',
					'10.10.28.152'=>'Febi',
					);
		return $allip[$ip];
	}
}