<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Relasi extends CI_Controller {
		public function __construct(){
			parent::__construct();
			if (!isset($_SESSION['login'])) {
				header("location: /presensi/login");
			}
			$this->load->model('presensimodel');
			$this->load->library('pagination');
		}

		public function testgmbr($gbr){
			if ($gbr=="null") {
				return "no pic";
			}else{
				return "<img style='width:50px;height:50px' src='".$gbr."'>";
			}
		}

		public function index(){
			
			if (empty($this->input->get("per_page"))) {
				$page=0;
			}else{
				$page=$this->input->get("per_page");
			}
			
			// $tgs=$this->input->get('tgs');
			// $tge=$this->input->get('tge');
			// if ($tgs=='' or $tge=='') {
			// 	$tge=date('Y-m-d');
			// 	$tgs=date('Y-m-d',strtotime($tge."-7 days"));
			// }
			// $this->load->library('table');
			//$result=$this->presensimodel->getcURL("http://api.kalau.web.id/api?nip=".$_SESSION['nip']."&tgs=".$tgs."&tge=".$tge);
			//$i=1;
			$this->table->set_heading('No','ID Finger','NIP','Tanggal Mulai','Tanggal Selesai','Aksi');
			$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/relasi");
			//$i=1;
			//$data['latest_update']=$result->relasi->latest_update;
			if (empty($result->relasi_data->data_relasi)) {
				$template = array(
			        'table_open'            => '<table class="table table-bordered table-hover">',
			        'thead_open'            => '<thead class="table_head">',
			        'thead_close'           => '</thead>',
			        'heading_row_start'     => '<tr>',
			        'heading_row_end'       => '</tr>',
			        'heading_cell_start'    => '<th class="header-table">',
			        'heading_cell_end'      => '</th>',
			        'tbody_open'            => '<tbody>',
			        'tbody_close'           => '</tbody>',
			        'row_start'             => '<tr>',
			        'row_end'               => '</tr>',
			        'cell_start'            => '<td colspan="6">',
				);
				$this->table->add_row("<p style='text-align:center'>Riwayat absensi tidak ditemukan.</p>");
			}else{

				//Objek Json	
				
				$dat=$result->relasi_data->data_relasi;
				$data['jml']=count($dat);
				//make single data
				$singleData= array();
				
				for ($i=0; $i <count($dat) ; $i++) {

						$parent = new stdClass; 
						$parent->id 		=$dat[$i]->finger_id;
						$parent->id_f 		=$dat[$i]->no_finger;
						$parent->nip 		=$dat[$i]->nip;
						$parent->tgl_mulai 		=$dat[$i]->created_date;
						$parent->tgl_selesai 		=$dat[$i]->end_date;
						//sementara
						$singleData[]		=$parent;
				}

				//sort yang terbaru
				// usort($singleData, function($a, $b) {
    // 				return strtotime($a->tgl) - strtotime($b->tgl);
				// });

				//paging require
				$totalData =count($singleData);
				$config['base_url']   		= "relasi";
				$config['total_rows'] 		= $totalData;
				$config['per_page']   		= 20;
				$config['page_query_string']=true;
				$config['num_links']   		= $totalData;
				//theme
				$config['prev_tag_open'] = '<span style="margin:5px">';
        		$config['prev_tag_close'] = '</span>';
        		$config['next_tag_open'] = '<span style="margin:5px">';
        		$config['mext_tag_close'] = '</span>';
				$config['full_tag_open'] = '<div>';
        		$config['full_tag_close'] = '</div>';
        		$config['cur_tag_open'] = '<span style="margin:5px">';
		        $config['cur_tag_close'] = '</span>';
		        $config['num_tag_open'] = '<span style="margin:5px">';
		        $config['num_tag_close'] = '</span>';
				$this->pagination->initialize($config);

				$singleData=array_slice($singleData, $page, 20 );
				$nomber=1;

				//add to table
				for ($i=0; $i < count($singleData) ; $i++) {
						// $date=explode(" ", $singleData[$i]->tgl);
						$this->table->add_row(
							$nomber."<p data-key='".$singleData[$i]->id."'></p>",
							$singleData[$i]->id_f,
							$singleData[$i]->nip,
							$singleData[$i]->tgl_mulai,
							$singleData[$i]->tgl_selesai,
							'<button onclick="popup.call(this)">Sanggah</button>'
						);	
						$nomber++;
				}
						$template = array(
					        'table_open'            => '<table id="mytable" class="table table-bordered table-hover">',
					        'thead_open'            => '<thead class="table_head">',
					        'thead_close'           => '</thead>',
					        'heading_row_start'     => '<tr>',
					        'heading_row_end'       => '</tr>',
					        'heading_cell_start'    => '<th class="header-table">',
					        'heading_cell_end'      => '</th>',
					        'tbody_open'            => '<tbody>',
					        'tbody_close'           => '</tbody>',
					        'row_start'             => '<tr>',
					        'row_end'               => '</tr>',
					        'cell_start'            => '<td style="text-align:center; vertical-align:middle">',
					        'cell_end'              => '</td>',
					        'row_alt_start'         => '<tr>',
					        'row_alt_end'           => '</tr>',
					        'cell_alt_start'        => '<td style="text-align:center; vertical-align:middle">',
					        'cell_alt_end'          => '</td>',
					        'table_close'           => '</table>'
						);				
			}
			$this->table->set_template($template);

			//generate the table
			$data['table']=$this->table->generate();
			// $data['tgs']  =$tgs;
			// $data['tge']  =$tge;
			$data['page'] =$this->pagination->create_links();
			if ($this->input->get('ajax')==true) {
				echo $data['table'];
				echo $data['page'];
			}else{
				$this->load->view('relasi', $data);
			}
			
		}

		function sanggah(){
			$id 	=$this->input->get("id");
			$nip 	=$this->input->get("nip");
			$tgl 	=$this->input->get("tgl")." ".$this->input->get("wkt");
			$preske	=$this->input->get("preske");
			$ket	=$this->input->get("ket");

			if ($this->input->get("tgl")=="" or $this->input->get("wkt")=="" or $preske==0 or $ket=="") {
				echo "Lengkapi data!";
			}else{
				//url api
				$url="http://api.kalau.web.id/api/sanggah";
				$data = array('id' 			=> $id ,
							  'nip'			=> $nip,
							  'presensi_ke'	=> $preske,
							  'tag_date'	=> $tgl,
							  'ket'			=> $ket);
				$send = $this->presensimodel->postcURL($url,$data);
				
				if ($send->status==true) {
					echo "Sanggahan terkirim";
				}else{
					echo "Sanggahan gagal terkirim, silahkan ulangi!";
				}
				
			}
			
		}
	}