/* Ambil Data dari Database Pegawai, menggunakan framework Codeigniter */
$param=array(
    "api_kode"=>?,
    "api_subkode"=>?,
    #parameter lainnya dimasukkan di sini
);
$url="http://service2.uin-suka.ac.id/servsimpeg/sia_public/sia_master/data_search"; #url API yang ada apa
$hasil1=json_decode($this->get_api_sia($url,'POST',$param),true); 
function get_api_sia($api_url, $postorget='GET', $parameter = array()){ #fungsi untuk menn
	$CI =& get_instance();
	$hasil = null;
	$CI->load->library('curl'); 
	$CI->curl->option('HTTPHEADER', array('HeaderName: adi'));
	if ($postorget == 'POST'){
		$hasil = $CI->curl->simple_post($api_url,$parameter);
	} else {
		$hasil = $CI->curl->simple_get($api_url);
	}
	return $hasil;
}

/* Ambil Data dari mesin fingerprint */
<html>
<head>
<meta http-equiv="refresh" content="300" > 
</head>
<body> 
<?php
error_reporting(0);
$ip='xx.xx.xx.xx'; #ip fingerprint
function post($url,$data) { 
	$process = curl_init();
	$options = array(
		CURLOPT_URL => $url,
		CURLOPT_HEADER => false,
		CURLOPT_POSTFIELDS => $data,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => TRUE,
		CURLOPT_POST => TRUE,
		CURLOPT_BINARYTRANSFER => TRUE
	);
	curl_setopt_array($process, $options);
	$return = curl_exec($process); 
	curl_close($process); 
	return $return; 
}
function ambil_data($url, $data){
	$hasil = post($url,$data);
	$hasil_arr = explode("\t",$hasil);
	$result['nama'] = $hasil_arr['1'];
	$jumlah = count($hasil_arr);
	$mod = round($jumlah / 4);
	$index = 2;
	$replace = array(" ", ":", "-");
	$waktu_index_awal = str_replace($replace,"",$hasil_arr[$index]);
	for($x=1;$x<=$mod;$x++){
		$index = $index + $counter;
		$counter = 4;
		$replace = array(" ", ":", "-");
		$waktu_index = str_replace($replace,"",$hasil_arr[$index]);
		if($waktu_index_awal >= $waktu_index){
			$waktu_index_awal = $waktu_index;
			$index_awal = $index;
		}
		if($waktu_index_akhir < $waktu_index){
			$waktu_index_akhir = $waktu_index;
			$index_akhir = $index;
		}
	}
	$result['datang'] = $hasil_arr[$index_awal];
	$result['pulang'] = $hasil_arr[$index_akhir];
	print_r($result);
}
function grab_data($idkar, $tanggal){
	global $ip;
	#$tanggal_awal='2016-05-24';
	#$tanggal_akhir='2016-05-24';
	#$idkar = '18005';
	$tanggal_awal = $tanggal;
	$tanggal_akhir = $tanggal;
	
	$data[]="sdate={$tanggal_awal}";
	$data[]="edate={$tanggal_akhir}";
	$data[]="uid={$idkar}";
	$data[]='period=1';
	$result = ambil_data("http://{$ip}/form/Download", implode('&',$data));
}
grab_data('18009','2016-05-24'); #18009=> id pegawai di fingerprint (bukan dari database pegawai), 2016-05-24 => tanggal akan diambil datanya
?>
</div>
</body>
</html>