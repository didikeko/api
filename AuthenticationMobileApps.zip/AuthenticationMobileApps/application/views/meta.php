<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- meta name="robots" content="index,follow" -->
		<meta name="robots" content="noindex,nofollow">
		<title>Sistem Informasi Akademik UIN Sunan Kalijaga</title>
		<link href="http://akademik.uin-suka.ac.id/asset/img/favicon.png" type="image/x-icon" rel="shortcut icon">
		<link href="http://akademik.uin-suka.ac.id/asset/css/style_global.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/style_sp_akademik.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/style.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/style_sp_post.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/style_hack.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/dynatree/dynatree.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/jquery.jqplot.min.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/redactor.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/docs.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/css_ui.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css">
		<link href="http://akademik.uin-suka.ac.id/asset/css/progtracker.css" rel="stylesheet" type="text/css">
		<style type="text/css">
			table.table-user { border: none; border-top: 1px solid #DDD; width: 100%; }
			table.table-user tr td { padding: 5px; border-top: 1px solid #DDD; border-right: 0px solid #DDD; border-left: 1px solid #DDD; }
			table.table-user tr:last-child td { border-bottom: 1px solid #DDD; }
			table.table-user tr td:last-child { border-right: 1px solid #DDD; }
			table.table-user tr td.snippet-label { width: 125px; font-weight: bold; background: #EEE; border-top: 1px solid #DDD; }
			table.table-user tr td.snippet-label2 { width: 85px; font-weight: bold; background: #EEE; border-top: 1px solid #DDD; }
			table.table-user tr:first-child td.snippet-label { border-top: none; }
			
			table.table-snippet tr td.snippet-label { width: 150px; font-weight: bold;  }
			table.table-snippet tr td { padding: 2px; }
			table tr td.tac { text-align: center; }
			table tr td.tal { text-align: left; }
			table tr td.tar { text-align: right; }
			a.link { text-decoration: underline; }
			#krs-warning { text-align: center; padding: 2%; border: 1px solid #CCC; background: #f2f2f2; }
			.txtasmt { /*color: #A4884A;*/ }
			input.btn-uin, input.btn-uin:hover, a.btn-uin:link, a.btn-uin:hover, a.btn-uin:visited, button.btn-uin, input.btn-uin:disabled, button.btn-uin:disabled {
				margin-top: -10px;
			}		
		</style>
		<script async="" src="//www.google-analytics.com/analytics.js"></script><script>var $site_url = 'http://akademik.uin-suka.ac.id/';</script>
		<script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-27090148-3', 'auto');ga('send', 'pageview');</script>
		
		<script src="http://akademik.uin-suka.ac.id/asset/js/core.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/js_ui.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/enhance.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/jQuery.fileinput.js"></script>
		<!-- custom scrollbars plugin -->
		<script src="http://akademik.uin-suka.ac.id/asset/js/jquery.mCustomScrollbar.min.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/jquery.mCustomScrollbar.init.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/redactor.min.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/bootstrap-datetimepicker.min.js"></script>
		<script src="http://akademik.uin-suka.ac.id/asset/js/bootstrap-timepicker.min.js"></script>
				
				
			</head>