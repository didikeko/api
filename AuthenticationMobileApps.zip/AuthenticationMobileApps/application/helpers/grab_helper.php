<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
header('Content-Type: application/json');
function post($url,$data) { 
	$process = curl_init();
	$options = array(
		CURLOPT_URL => $url,
		CURLOPT_HEADER => false,
		CURLOPT_POSTFIELDS => $data,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => TRUE,
		CURLOPT_POST => TRUE,
		CURLOPT_BINARYTRANSFER => TRUE
	);
	curl_setopt_array($process, $options);
	$return = curl_exec($process); 
	curl_close($process); 
	return $return; 
}
function ambil_data($url, $data){
	$hasil = post($url,$data);
	$hasil_arr = explode("\t",$hasil);
	$result['nama'] = $hasil_arr['1'];
	$jumlah = count($hasil_arr);
	$mod = round($jumlah / 4);
	$index = 2;
	$replace = array(" ", ":", "-");
	$waktu_index_awal = str_replace($replace,"",$hasil_arr[$index]);
	for($x=1;$x<=$mod;$x++){
		$index = $index + $counter;
		$counter = 4;
		$replace = array(" ", ":", "-");
		$waktu_index = str_replace($replace,"",$hasil_arr[$index]);
		if($waktu_index_awal >= $waktu_index){
			$waktu_index_awal = $waktu_index;
			$index_awal = $index;
		}
		if($waktu_index_akhir < $waktu_index){
			$waktu_index_akhir = $waktu_index;
			$index_akhir = $index;
		}
	}
	$result['datang'] = $hasil_arr[$index_awal];
	$result['pulang'] = $hasil_arr[$index_akhir];
	echo json_encode($result, JSON_PRETTY_PRINT);
	//print_r($result);
}
function grab_data($idkar, $tanggal, $ip){
	//global $ip;
	//tanggal_awal='2016-05-24';
	//$tanggal_akhir='2016-05-24';
	//$idkar = '18005';
	$tanggal_awal = $tanggal;
	$tanggal_akhir = $tanggal;
	
	$data[]="sdate={$tanggal_awal}";
	$data[]="edate={$tanggal_akhir}";
	$data[]="uid={$idkar}";
	$data[]='period=1';
	$result = ambil_data("http://{$ip}/form/Download", implode('&',$data));
}
/*
//$ip='10.10.28.139';
function post($url,$data) { 
	$process = curl_init();
	$options = array(
		CURLOPT_URL => $url,
		CURLOPT_HEADER => false,
		CURLOPT_POSTFIELDS => $data,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => TRUE,
		CURLOPT_POST => TRUE,
		CURLOPT_BINARYTRANSFER => TRUE
	);
	curl_setopt_array($process, $options);
	$return = curl_exec($process); 
	curl_close($process); 
	return $return; 
}

function ambil_data($url, $data){
	$hasil = post($url,$data);
	$hasil_arr = explode("\t",$hasil);
	$result['nama'] = $hasil_arr['1'];
	$jumlah = count($hasil_arr);
	$mod = round($jumlah / 4);
	$index = 2;
	$replace = array(" ", ":", "-");
	$waktu_index_awal = str_replace($replace,"",$hasil_arr[$index]);
	for($x=1;$x<=$mod;$x++){
		$index = $index + $counter;
		$counter = 4;
		$replace = array(" ", ":", "-");
		$waktu_index = str_replace($replace,"",$hasil_arr[$index]);
		if($waktu_index_awal >= $waktu_index){
			$waktu_index_awal = $waktu_index;
			$index_awal = $index;
		}
		if($waktu_index_akhir < $waktu_index){
			$waktu_index_akhir = $waktu_index;
			$index_akhir = $index;
		}
	}
	$result['datang'] = $hasil_arr[$index_awal];
	$result['pulang'] = $hasil_arr[$index_akhir];
	return $result;
	//print_r($result);
}

function grab_data($idkar, $tanggal, $ip){
	global $ip;
	#$tanggal_awal='2016-05-24';
	#$tanggal_akhir='2016-05-24';
	#$idkar = '18005';
	$tanggal_awal = $tanggal;
	$tanggal_akhir = $tanggal;
	
	$data[]="sdate={$tanggal_awal}";
	$data[]="edate={$tanggal_akhir}";
	$data[]="uid={$idkar}";
	$data[]='period=1';
	$result = ambil_data("http://{$ip}/form/Download", implode('&',$data));
}
*/
