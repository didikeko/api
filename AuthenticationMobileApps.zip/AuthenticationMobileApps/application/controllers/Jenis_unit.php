<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Jenis_unit extends CI_Controller {
		public function __construct(){
			parent::__construct();
			if (!isset($_SESSION['login'])) {
				header("location: /presensi/login");
			}
			$this->load->model('presensimodel');
			$this->load->library('pagination');
		}

		public function testgmbr($gbr){
			if ($gbr=="null") {
				return "no pic";
			}else{
				return "<img style='width:50px;height:50px' src='".$gbr."'>";
			}
		}

		public function index(){
			
			
			
			if (empty($this->input->get("per_page"))) {
				$page=0;
			}else{
				$page=$this->input->get("per_page");
			}
			
			$tgs=$this->input->get('tgs');
			$tge=$this->input->get('tge');
			$unit=$this->input->get('unit');
			// $nip=$this->input->get('tge');
			if ($tgs=='' or $tge=='') {
				$tge=date('Y-m-d');
				$tgs=date('Y-m-d',strtotime($tge."-7 days"));
			}
			$this->load->library('table');
			$this->table->set_heading('No','NIP','Tanggal','Waktu','Ke-','Lokasi','Foto','Perangkat','Aksi');
			//$result=$this->presensimodel->getcURL("http://api.kalau.web.id/api?nip=".$_SESSION['nip']."&tgs=".$tgs."&tge=".$tge);
			$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/absen_jenis_unit?tgs=".$tgs."&tge=".$tge."&unit=".$unit);
			
			//$i=1;
			//$data['latest_update']=$result->presensi->latest_update;
			if (empty($result->presensi_unit->data_absensi_unit)) {
				$template = array(
			        'table_open'            => '<table class="table table-bordered table-hover">',
			        'thead_open'            => '<thead class="table_head">',
			        'thead_close'           => '</thead>',
			        'heading_row_start'     => '<tr>',
			        'heading_row_end'       => '</tr>',
			        'heading_cell_start'    => '<th class="header-table">',
			        'heading_cell_end'      => '</th>',
			        'tbody_open'            => '<tbody>',
			        'tbody_close'           => '</tbody>',
			        'row_start'             => '<tr>',
			        'row_end'               => '</tr>',
			        'cell_start'            => '<td colspan="9">',
				);
				$this->table->add_row("<p style='text-align:center'>Riwayat absensi tidak ditemukan.</p>");
			}else{

				
				//make single data
				$singleData=array();

				if ($unit=='mobile') {
					$dat=$result->presensi_unit->data_absensi_unit;
				    $data['jml']=count($dat);
					for ($i=0; $i <count($dat) ; $i++) {
						$parent = new stdClass;
						$parent->id 	=$dat[$i]->id;
						$parent->nip 	=$dat[$i]->nip;
						$parent->tgl 	=$dat[$i]->created_at;
						$parent->preske =$dat[$i]->presensi_ke;
						$parent->lokasi =$this->presensimodel->getLocations($dat[$i]->latitude,$dat[$i]->longitude);
						$parent->foto 	=$dat[$i]->photo;
						$parent->mac 	=$dat[$i]->macaddress;
						$singleData[]	=$parent;
					}
				}else{
					$dat2=$result->presensi_unit->data_absensi_unit;
					$data['jml']=count($dat2);
					for ($i=0; $i <count($dat2) ; $i++) {
							$parent2 = new stdClass; 
							$time=explode(' ',$dat2[$i]->tag_date);
							$parent2->id 		=$dat2[$i]->finger_id;
							$parent2->nip 		=$dat2[$i]->nip;
							$parent2->tgl 		=$dat2[$i]->tag_date;
							//sementara
							$parent2->preske 	=$this->presensimodel->indexWaktu($time[1]);
							$parent2->lokasi 	=$this->presensimodel->getUnit($dat2[$i]->finger_ip);
							$parent2->foto 		="null";
							$parent2->mac 		=$dat2[$i]->finger_ip;
							$singleData[]		=$parent2;
					}	
				}
				

				//sort yang terbaru
				usort($singleData, function($a, $b) {
    				return strtotime($a->tgl) - strtotime($b->tgl);
				});

				//paging require
				$totalData =count($singleData);
				$config['base_url']   		= "unit?tgs=".$tgs."&tge=".$tge;
				$config['total_rows'] 		= $totalData;
				$config['per_page']   		= 15;
				$config['page_query_string']=true;
				$config['num_links']   		= $totalData;
				//theme
				$config['prev_tag_open'] = '<span style="margin:5px">';
        		$config['prev_tag_close'] = '</span>';
        		$config['next_tag_open'] = '<span style="margin:5px">';
        		$config['mext_tag_close'] = '</span>';
				$config['full_tag_open'] = '<div>';
        		$config['full_tag_close'] = '</div>';
        		$config['cur_tag_open'] = '<span style="margin:5px">';
		        $config['cur_tag_close'] = '</span>';
		        $config['num_tag_open'] = '<span style="margin:5px">';
		        $config['num_tag_close'] = '</span>';
				$this->pagination->initialize($config);

				$singleData=array_slice($singleData, $page, 15 );
				$nomber=1;

				//add to table
				for ($i=0; $i < count($singleData) ; $i++) {
						$date=explode(" ", $singleData[$i]->tgl);
						$this->table->add_row(
							$nomber."<p data-key='".$singleData[$i]->id."'></p>",
							$singleData[$i]->nip,
							$date[0],
							$date[1],
							$singleData[$i]->preske,
							"<p id='location' title='Latitude' style='max-width:300px;text-align:left'>"
							  .$singleData[$i]->lokasi.
							"</p>",
							$this->testgmbr($singleData[$i]->foto),
							$singleData[$i]->mac,
							'<button onclick="popup.call(this)">Sanggah</button>'
						);	
						$nomber++;
				}
						$template = array(
					        'table_open'            => '<table id="mytable" class="table table-bordered table-hover">',
					        'thead_open'            => '<thead class="table_head">',
					        'thead_close'           => '</thead>',
					        'heading_row_start'     => '<tr>',
					        'heading_row_end'       => '</tr>',
					        'heading_cell_start'    => '<th class="header-table">',
					        'heading_cell_end'      => '</th>',
					        'tbody_open'            => '<tbody>',
					        'tbody_close'           => '</tbody>',
					        'row_start'             => '<tr>',
					        'row_end'               => '</tr>',
					        'cell_start'            => '<td style="text-align:center; vertical-align:middle">',
					        'cell_end'              => '</td>',
					        'row_alt_start'         => '<tr>',
					        'row_alt_end'           => '</tr>',
					        'cell_alt_start'        => '<td style="text-align:center; vertical-align:middle">',
					        'cell_alt_end'          => '</td>',
					        'table_close'           => '</table>'
						);				
			}
			$this->table->set_template($template);

			//generate the table
			$data['table']=$this->table->generate();
			$data['tgs']  =$tgs;
			$data['tge']  =$tge;
			$data['page'] =$this->pagination->create_links();
			if ($this->input->get('ajax')==true) {
				echo $data['table'];
				echo $data['page'];
			}else{
				$this->load->view('presensi_unit', $data);
			}
			
		}

/////
		public function unit_nip(){
			if (empty($this->input->get("per_page"))) {
				$page=0;
			}else{
				$page=$this->input->get("per_page");
			}
			$nip=$this->input->get('nip');
			$tgs=$this->input->get('tgs');
			$tge=$this->input->get('tge');
			// $unit=$this->input->get('unit');
			// $nip=$this->input->get('tge');
			if ($tgs=='' or $tge=='') {
				$tge=date('Y-m-d');
				$tgs=date('Y-m-d',strtotime($tge."-7 days"));
			}
			$this->load->library('table');
			$this->table->set_heading('No','NIP','Tanggal','Waktu','Ke-','Lokasi','Foto','Perangkat','Aksi');
			//$result=$this->presensimodel->getcURL("http://api.kalau.web.id/api?nip=".$_SESSION['nip']."&tgs=".$tgs."&tge=".$tge);
			$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/absen?nip=".$nip."tgs=".$tgs."&tge=".$tge);
			// if($unit){
			// 	$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/absen_jenis_unit?tgs=".$tgs."&tge=".$tge."&unit=".$unit);
			// }elseif($nip){
			// 	$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/absen?nip=".$_SESSION['nip']."&tgs=".$tgs."&tge=".$tge);
			// }else{
			// 	$result=$this->presensimodel->getcURL("http://service2.uin-suka.ac.id/presensi/api/absenunit?tgs=".$tgs."&tge=".$tge);
			// }
			//$i=1;
			//$data['latest_update']=$result->presensi->latest_update;
			if (empty($result->presensi->data_absensi_mobile) AND empty($result->presensi->data_absensi_finger)) {
				$template = array(
			        'table_open'            => '<table class="table table-bordered table-hover">',
			        'thead_open'            => '<thead class="table_head">',
			        'thead_close'           => '</thead>',
			        'heading_row_start'     => '<tr>',
			        'heading_row_end'       => '</tr>',
			        'heading_cell_start'    => '<th class="header-table">',
			        'heading_cell_end'      => '</th>',
			        'tbody_open'            => '<tbody>',
			        'tbody_close'           => '</tbody>',
			        'row_start'             => '<tr>',
			        'row_end'               => '</tr>',
			        'cell_start'            => '<td colspan="9">',
				);
				$this->table->add_row("<p style='text-align:center'>Riwayat absensi tidak ditemukan.</p>");
			}else{

				//Objek Json	
				$dat=$result->presensi->data_absensi_mobile;
				$dat2=$result->presensi->data_absensi_finger;
				$data['jml']=count($dat);
				//make single data
				$singleData= array();

				for ($i=0; $i <count($dat) ; $i++) {
						$parent = new stdClass;
						$parent->id 	=$dat[$i]->id;
						$parent->nip 	=$dat[$i]->nip;
						$parent->tgl 	=$dat[$i]->created_at;
						$parent->preske =$dat[$i]->presensi_ke;
						$parent->lokasi =$this->presensimodel->getLocations($dat[$i]->latitude,$dat[$i]->longitude);
						$parent->foto 	=$dat[$i]->photo;
						$parent->mac 	=$dat[$i]->macaddress;
						$singleData[]	=$parent;
				}

				for ($i=0; $i <count($dat2) ; $i++) {

						$parent2 = new stdClass; 
						$time=explode(' ',$dat2[$i]->tag_date);
						$parent2->id 		=$dat2[$i]->finger_id;
						$parent2->nip 		=$dat2[$i]->nip;
						$parent2->tgl 		=$dat2[$i]->tag_date;
						//sementara
						$parent2->preske 	=$this->presensimodel->indexWaktu($time[1]);
						$parent2->lokasi 	=$this->presensimodel->getUnit($dat2[$i]->finger_ip);
						$parent2->foto 		="null";
						$parent2->mac 		=$dat2[$i]->finger_ip;
						$singleData[]		=$parent2;
				}

				//sort yang terbaru
				usort($singleData, function($a, $b) {
    				return strtotime($a->tgl) - strtotime($b->tgl);
				});

				//paging require
				$totalData =count($singleData);
				$config['base_url']   		= "unit?tgs=".$tgs."&tge=".$tge;
				$config['total_rows'] 		= $totalData;
				$config['per_page']   		= 15;
				$config['page_query_string']=true;
				$config['num_links']   		= $totalData;
				//theme
				$config['prev_tag_open'] = '<span style="margin:5px">';
        		$config['prev_tag_close'] = '</span>';
        		$config['next_tag_open'] = '<span style="margin:5px">';
        		$config['mext_tag_close'] = '</span>';
				$config['full_tag_open'] = '<div>';
        		$config['full_tag_close'] = '</div>';
        		$config['cur_tag_open'] = '<span style="margin:5px">';
		        $config['cur_tag_close'] = '</span>';
		        $config['num_tag_open'] = '<span style="margin:5px">';
		        $config['num_tag_close'] = '</span>';
				$this->pagination->initialize($config);

				$singleData=array_slice($singleData, $page, 15 );
				$nomber=1;

				//add to table
				for ($i=0; $i < count($singleData) ; $i++) {
						$date=explode(" ", $singleData[$i]->tgl);
						$this->table->add_row(
							$nomber."<p data-key='".$singleData[$i]->id."'></p>",
							$singleData[$i]->nip,
							$date[0],
							$date[1],
							$singleData[$i]->preske,
							"<p id='location' title='Latitude' style='max-width:300px;text-align:left'>"
							  .$singleData[$i]->lokasi.
							"</p>",
							$this->testgmbr($singleData[$i]->foto),
							$singleData[$i]->mac,
							'<button onclick="popup.call(this)">Sanggah</button>'
						);	
						$nomber++;
				}
						$template = array(
					        'table_open'            => '<table id="mytable" class="table table-bordered table-hover">',
					        'thead_open'            => '<thead class="table_head">',
					        'thead_close'           => '</thead>',
					        'heading_row_start'     => '<tr>',
					        'heading_row_end'       => '</tr>',
					        'heading_cell_start'    => '<th class="header-table">',
					        'heading_cell_end'      => '</th>',
					        'tbody_open'            => '<tbody>',
					        'tbody_close'           => '</tbody>',
					        'row_start'             => '<tr>',
					        'row_end'               => '</tr>',
					        'cell_start'            => '<td style="text-align:center; vertical-align:middle">',
					        'cell_end'              => '</td>',
					        'row_alt_start'         => '<tr>',
					        'row_alt_end'           => '</tr>',
					        'cell_alt_start'        => '<td style="text-align:center; vertical-align:middle">',
					        'cell_alt_end'          => '</td>',
					        'table_close'           => '</table>'
						);				
			}
			$this->table->set_template($template);

			//generate the table
			$data['table']=$this->table->generate();
			$data['nip'] =$nip;
			$data['tgs']  =$tgs;
			$data['tge']  =$tge;
			$data['page'] =$this->pagination->create_links();
			if ($this->input->get('ajax')==true) {
				echo $data['table'];
				echo $data['page'];
			}else{
				$this->load->view('presensi_unit', $data);
			}
		} 

		function sanggah(){
			$id 	=$this->input->get("id");
			$nip 	=$this->input->get("nip");
			$tgl 	=$this->input->get("tgl")." ".$this->input->get("wkt");
			$preske	=$this->input->get("preske");
			$ket	=$this->input->get("ket");

			if ($this->input->get("tgl")=="" or $this->input->get("wkt")=="" or $preske==0 or $ket=="") {
				echo "Lengkapi data!";
			}else{
				//url api
				$url="http://service2.uin-suka.ac.id/presensi/api/sanggah";
				$data = array('id' 			=> $id ,
							  'nip'			=> $nip,
							  'presensi_ke'	=> $preske,
							  'tag_date'	=> $tgl,
							  'ket'			=> $ket);
				$send = $this->presensimodel->postcURL($url,$data);
				
				if ($send->status==true) {
					echo "Sanggahan terkirim";
				}else{
					print_r($data);
					var_dump($send);
					echo "Sanggahan gagal terkirim, silahkan ulangi!";
				}
				
			}
			
		}
	}