<?php
function get_all_string_between($string, $start, $end)
{
    $result = array();
    $string = " ".$string;
    $offset = 0;
    while(true)
    {
        $ini = strpos($string,$start,$offset);
        if ($ini == 0)
            break;
        $ini += strlen($start);
        $len = strpos($string,$end,$ini) - $ini;
        $result[] = substr($string,$ini,$len);
        $offset = $ini+$len;
    }
    return $result;
}
function masukkandata($ip){
	$url = "http://$ip/csl/user";
	$isi = file_get_contents($url);
	$isi1 = get_all_string_between($isi,"<table cellpadding=2 cellspacing=2 border=0>","</table>");
	$isi2 = $isi1[1];
	$isi3 = get_all_string_between($isi2,"<td width=15%>","</td>");
	$urut=0;
	$n2 = 0;
	for($x=0;$x<count($isi3);$x++){
		$mod = $x % 2;
		if($mod == 1){
			$urut++;
			$namanya = $isi3[$x];
			//eksekusi di sini
			#$sql2 = mysql_query("select * from nama_table where ip = '$ip' and id = '$idnya'");
			#$n2 = mysql_num_rows($sql2);
			if($n2 < 1){
				//insert data baru
				$sql3 = "insert into nama_table(ip,id,nama) values ('$ip','$idnya','$namanya')";
				echo $sql3."<br/>";
			}
		}else{
			$idnya = $isi3[$x];
		}
	}
}

$array_ip = array('10.10.28.129','10.10.28.131','10.10.28.132','10.10.28.133','10.10.28.134',
	'10.10.28.135','10.10.28.136','10.10.28.137','10.10.28.138','10.10.28.139','10.10.28.140',
	'10.10.28.141','10.10.28.142','10.10.28.143','10.10.28.145','10.10.28.146','10.10.28.152','10.10.28.153');
for($x=0;$x<count($array_ip);$x++){
		echo "<div style='color:red;font-weight:bold'>JALAN UNTUK IP ".$array_ip[$x]."</div>";
		masukkandata($array_ip[$x]);
		echo "<br/><br/>";
sleep(5);
}

// $array_ip = array('10.10.28.133');
// for($x=0;$x<count($array_ip);$x++){
// 	echo "<div style='color:red;font-weight:bold'>JALAN UNTUK IP ".$array_ip[$x]."</div>";
// 	masukkandata($array_ip[$x]);
// 	echo "<br/><br/>";
// 	sleep(10);
// }

?>