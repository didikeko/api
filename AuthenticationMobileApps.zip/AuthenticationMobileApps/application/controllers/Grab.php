<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Grab extends CI_Controller {
		public function __construct() {
        	parent::__construct();
        	$this->load->model('model_data');
        	$this->load->helper('grab');
    	}
    	public function api_sia(){
    		$ip 	= "10.10.28.131";
    		echo var_dump($this->take_user($ip));
    		$data   = $this->model_data->insert_user_finger();
    		//$array_ip = array('10.10.28.133');
			// for($x=0;$x<count($array_ip);$x++){
			// 	var_dump($this->take_user($ip[$x]));
			// }
    		
    	}
    	private function take_user($ip){
    		$url = "http://$ip/csl/user";
			$isi = file_get_contents($url);
			$isi1 = $this->get_all_string_between($isi,"<table cellpadding=2 cellspacing=2 border=0>","</table>");
			$isi2 = $isi1[1];
			$isi3 = $this->get_all_string_between($isi2,"<td width=15%>","</td>");
			$urut=0;
			$n2 = 0;
			//var_dump($isi3);
			for($x=0;$x<count($isi3);$x++){
				$mod = $x % 2;
				if($mod == 1){
					$urut++;
					$namanya = $isi3[$x];
					//eksekusi di sini
					#$sql2 = mysql_query("select * from nama_table where ip = '$ip' and id = '$idnya'");
					#$n2 = mysql_num_rows($sql2);
					if($n2 < 1){
						//insert data baru
						$sql3 = "insert into nama_table(ip,id,nama) values ('$ip','$idnya','$namanya')";
						echo $sql3."<br/>";
						
						
					}
				}else{
					$idnya = $isi3[$x];
					echo $idnya;
				}		
			}
    	}
    	private function get_all_string_between($string, $start, $end)
		{
		    $result = array();
		    $string = " ".$string;
		    $offset = 0;
		    while(true)
		    {
		        $ini = strpos($string,$start,$offset);
		        if ($ini == 0)
		            break;
		        $ini += strlen($start);
		        $len = strpos($string,$end,$ini) - $ini;
		        $result[] = substr($string,$ini,$len);
		        $offset = $ini+$len;
		    }
		    return $result;
		}
		public function grabber(){
			$uid = $this->input->get('uid');
			$tgl = $this->input->get('date');
			$ser = $this->input->get('service');
			return grab_data($uid, $tgl, $ser);
		}
		public function checksite(){
		    echo 'Muncul';
        }
		public function cron_scheduler($ipunit){
		    $tanggal    = date('Y-m-d');
            $server	 = array(
                "10.10.28.129","10.10.28.130",
                "10.10.28.131","10.10.28.132",
                "10.10.28.133","10.10.28.134",
                "10.10.28.135","10.10.28.136",
                "10.10.28.137","10.10.28.138",
                "10.10.28.139","10.10.28.140",
                "10.10.28.141","10.10.28.142",
                "10.10.28.143","10.10.28.145",
                "10.10.28.146","10.10.28.152",
            );
            $pegawai    = $this->model_data->get_data();
            for($i=0; $i<count($pegawai); $i++){
                $uid= $pegawai[$i]['no_finger'];
                $uid2= $pegawai[$i]['finger_id'];
                $check=file_get_contents("http://service2.uin-suka.ac.id/presensi/grab/grabber?uid=".$uid."&date=".$tanggal."&service=".$server[$ipunit]);
                $checkable=json_decode($check, 0);
                print_r($checkable);
                if(isset($checkable->nama)){
                    $tagfirst['nama']		= $checkable->nama;
                    $tagfirst['tag_date']	= $checkable->datang;
                    $tagfirst['fingerId']	= $uid2;
                    $tagfirst['ip'] 		= $server[$ipunit];
                    $tagend['nama']	    	= $checkable->nama;
                    $tagend['tag_date']		= $checkable->pulang;
                    $tagend['fingerId']		= $uid2;
                    $tagend['ip']			= $server[$ipunit];
                    $this->model_data->insert_data_finger($tagfirst);
                    $this->model_data->insert_data_finger($tagend);
                }
            }
        }
		public function scheduler(){
			$tanggal = $this->input->get('tanggal');
			$server	 = array(
				"10.10.28.129","10.10.28.130",
				"10.10.28.131","10.10.28.132",
				"10.10.28.133","10.10.28.134",
				"10.10.28.135","10.10.28.136",
				"10.10.28.137","10.10.28.138",
				"10.10.28.139","10.10.28.140",
				"10.10.28.141","10.10.28.142",
				"10.10.28.143","10.10.28.145",
				"10.10.28.146","10.10.28.152",
				);
			
			$countserver	= count($server);
			for($start=0; $start< $countserver; $start++){
				$pegawai = $this->model_data->get_data();
				for($i=0; $i<count($pegawai); $i++){
					$uid= $pegawai[$i]['no_finger'];
					$uid2= $pegawai[$i]['finger_id'];
					$check=file_get_contents("http://service2.uin-suka.ac.id/presensi/grab/grabber?uid=".$uid."&date=".$tanggal."&service=".$server[$start]);
					$checkable=json_decode($check, 0);
					print_r($checkable);
					if(isset($checkable->nama)){
						$tagfirst['nama']		= $checkable->nama;
						$tagfirst['tag_date']	= $checkable->datang;
						$tagfirst['fingerId']	= $uid2;
						$tagfirst['ip'] 		= $server[$start];
						$tagend['nama']	    	= $checkable->nama;
						$tagend['tag_date']		= $checkable->pulang;
						$tagend['fingerId']		= $uid2;
						$tagend['ip']			= $server[$start];
						$this->model_data->insert_data_finger($tagfirst);
						$this->model_data->insert_data_finger($tagend);
					}
				}
			}
		}
		// public function index(){
    	// 	$noFinger='18009';
    	// 	$dateh	 ='2016-12-31';
    	// 	$ip		 ='10.10.28.139';
    	// 	$tanggal =date('Y-m-d');
    	// 	$result    =grab_data($noFinger, $dateh, $ip);
    	// 	$dataDatang     = array('fingerId'=> $noFinger,
    	// 					   		'tag_date'=> $result['datang'],
    	// 					   		'ip'      => $ip);
    	// 	$dataPulang	    = array('fingerId'=> $noFinger,
    	// 					   		'tag_date'=> $result['pulang'],
    	// 					   		'ip'      => $ip);
     //        print_r($dataDatang);
    	// 	//$this->model_data->insert_data_finger($dataDatang);
    	// 	//$this->model_data->insert_data_finger($dataPulang);
    	// }
	}