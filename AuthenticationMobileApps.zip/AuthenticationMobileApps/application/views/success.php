<?php
	defined('BASEPATH') or exit('No direct script allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Registration successfull</title>
</head>
<body>
	<div class="container">
			
	</div>
</body>
</html>