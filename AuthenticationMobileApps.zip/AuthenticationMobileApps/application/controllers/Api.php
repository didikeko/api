<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	require APPPATH.'/libraries/REST_Controller.php';

	class Api extends REST_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('model_data');
		}

/*
		public function siswa_get(){
			$this->response('My first API response = GET METHOD');
		}

		public function siswa_arr_get(){
			$siswa= $this->model_data->ambil_data()->result();
			$this->response($siswa);
		}

		public function siswa_post(){
			$this->response('My first API response = POST METHOD');
		}

		public function siswa_delete(){
			$this->response('My first API response = DELETE METHOD');
		}

		public function waktu_post(){
	        date_default_timezone_set('Asia/Jakarta');
	        $time=array('server-time'=>date('Y-m-d H:i:s'));
	        $this->response($time, 200);
	    }
	    public function count_mhs_get(){
	    	$data=
	    	$data= array(
	    			"jumlah" => $this->model_data->get_count_mhs()
	    		);
	    	$this->response($data,200);
	    }

//################################################################################
	    public function absen_full_get(){
	    	date_default_timezone_set('Asia/Jakarta');
	    	$data = array(
	    			  'Presensi'=>
	    				array(
			    			'Data Absensi Mobile' 	   => $this->model_data->take_data_absen_mobile()->result() ,
			    			'Data Absensi Finger'      => $this->model_data->take_data_absen_finger()->result() ,
			    			'Time Server' 			   => date('Y-m-d H:i:s')));
	    	$this->response($data,200);
	    }
	    public function absen_get(){
	    	date_default_timezone_set('Asia/Jakarta');
	    	$nip=$this->get('nip');
	    	$month=$this->get('month');
	    	$data = array(
	    			  'Presensi'=>
		    			array(
		    			'Data Absensi Mobile' 	   => $this->model_data->take_data_absen_mobile2($nip,$month),
		    			'Data Absensi Finger'      => $this->model_data->take_data_absen_finger2($nip,$month),
		    			'Time Server' => date('Y-m-d H:i:s')));
	    	//$json=json_encode($data);
	    	$this->response($data,200);
	    }

	    public function absen_post(){
	    	//$data= (array)json_decode(file_get_contents('php://input'));
			$data=array(
				   'nip'       => $this->post['nip'],
				   'latitude'  => $this->post['latitude'],
				   'longitude' => $this->post['longitude'],
				   'photo'	   => $this->post['photo'],
				   'macaddress'=> $this->post['macaddress'],
				   'created_at'=> $this->post['created_at']);
	    	$this->model_data->insert_data_mobile($data);
	    	$info= array(
	    		   'Success'=> true,
	    		   'info'	=> 'Data Tersimpan');
	    	$this->response($info,200);
	    }
	    public function update_absen_put(){
	    	$nip=$this->get('nip');
	    	$data= (array)json_decode(file_get_contents('php://input'));
	    	$this->model_data->update_data_mobile($data,$nip);
	    	$info= array(
	    		   'Success'=> true,
	    		   'info'	=> 'Data Updated');
	    	$this->response($info,200);
	    }
	    public function absen_delete(){
	    	$nip=$this->get('nip');
	    	$this->model_data->delete_data_mobile($nip);
	    	$info= array(
	    		   'Success'=> true,
	    		   'info'	=> 'Data deleted');
	    	$this->response($info,200);
	    }
	    //-----------------------------------------------------------------------------
	    public function data_absen_get(){
	    	date_default_timezone_set('Asia/Jakarta');
	    	$data = array(
	    				'Presensi'=>array(
					    			'Data Absensi Mobile' 	   => $this->model_data->take_data_absen_mobile3() ,
					    			'Data Absensi Finger'      => $this->model_data->take_data_absen_finger3() ,
					    			'Time Server' => date('Y-m-d H:i:s')));
	    	//$json=json_encode($data);
	    	$this->response($data,200);
	    }
	    /* Ambil Data dari Database Pegawai, menggunakan framework Codeigniter */


	    public function absen_nim_get($nip){
	    	date_default_timezone_set('Asia/Jakarta');
	    	$data = array(
	    				'Presensi'=>array(
					    			'Data Absensi Mobile' 	   => $this->model_data->take_data_absen_mobile4($nip) ,
					    			'Data Absensi Finger'      => $this->model_data->take_data_absen_finger4($nip) ,
					    			'Time Server' => date('Y-m-d H:i:s')
                        )
            );
	    	//$json=json_encode($data);
	    	$this->response($data,200);
	    }
	    
	    //get absen pegawai pribadi
	    public function absen_get(){
            header('Content-Type: application/json');
	    	$nip		=$this->get('nip');
	    	$tgl_awal	=$this->get('tgs');
	    	$tgl_akhir	=$this->get('tge');
	    	if (is_null($nip) or is_null($tgl_awal) or is_null($tgl_akhir)) {
	    		$data = array('status' => 'error' , 'data' => 'null' );
	    		$this->response($data,200);
	    	}else{
	    		date_default_timezone_set('Asia/Jakarta');
		    	$data = array(
		    			  'presensi'=>
		    				array(
				    			'data_absensi_mobile' 	   => $this->model_data->take_absen_m_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir),
				    			'data_absensi_finger'      => $this->model_data->take_absen_f_by_nip_between_tgl($nip,$tgl_awal,$tgl_akhir),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
		    	$this->response($data,200);
		    	//$this->response($data,200,JSON_PRETTY_PRINT);
                //echo json_encode($data, JSON_PRETTY_PRINT);
	    	}
	    }
		
		//get absen semua
	    public function absenunit_get(){
	    	header('Content-Type: application/json');
	    	$tgl_awal	=$this->get('tgs');
	    	$tgl_akhir	=$this->get('tge');
	    	if (is_null($tgl_awal) or is_null($tgl_akhir)) {
	    		$data = array('status' => 'error' , 'data' => 'null' );
	    		$this->response($data,200);
	    	}else{
	    		date_default_timezone_set('Asia/Jakarta');
		    	$data = array(
		    			  'presensi_unit'=>
		    				array(
				    			'data_absensi_unit_mobile' 	   => $this->model_data->take_absen_all_m_between_tgl($tgl_awal,$tgl_akhir),
				    			'data_absensi_unit_finger'      => $this->model_data->take_absen_all_f_between_tgl($tgl_awal,$tgl_akhir),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
		    	$this->response($data,200);
		    	echo json_encode($data, JSON_PRETTY_PRINT);
	    	}
	    }
	    //get absen pegawai per unit
	    public function absen_jenis_unit_get(){
	    	header('Content-Type: application/json');
	    	$unit 		=$this->get('unit');
	    	$tgl_awal	=$this->get('tgs');
	    	$tgl_akhir	=$this->get('tge');
	    	if (is_null($tgl_awal) or is_null($tgl_akhir) or is_null($unit)) {
	    		$data = array('status' => 'error' , 'data' => 'null' );
	    		$this->response($data,200);
	    	}else{
	    		date_default_timezone_set('Asia/Jakarta');
	    		if ($unit=='mobile') {
	    			$data = array(
		    			  'presensi_unit'=>
		    				array(
				    			'data_absensi_unit' 	   => $this->model_data->take_absen_all_m_between_tgl($tgl_awal,$tgl_akhir),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
	    		}else{
	    			$data = array(
		    			  'presensi_unit'=>
		    				array(
				    			'data_absensi_unit' 	   => $this->model_data->take_absen_unit($tgl_awal,$tgl_akhir,$unit),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
	    		}
		    	$this->response($data,200);
	    	}
	    }

	    public function absen_post(){
	    	//$data= (array)json_decode(file_get_contents('php://input'));
	    	
	    	$nip  	    = $this->post('nip');
		    $latitude  	= $this->post('latitude');
		    $longitude 	= $this->post('longitude');
		    $photo	   	= $this->post('photo');
		    $macaddress = $this->post('macaddress');	
		    $created_at = $this->post('created_at');
		    $ambilTgl	= explode(' ',$created_at,0);
		    $jmlhObjct= $this->model_data->presensiKe($ambilTgl[0],$nip);
		    $presensi_ke=$jmlhObjct[0]->jmlh + 1;		
			if ($nip=='' or $latitude=='' or $longitude=='' or $photo=='' or $macaddress=='' or $created_at=='') {
	    		$data = array('status' => 'error' , 'ket' => 'Please complete the parameter' );
	    		$this->response($data,200);
	    	}else{
				$data=array(
					   'nip'        => $nip,
					   'latitude'   => $latitude,
					   'longitude'  => $longitude,
					   'photo'	    => $photo,
					   'macaddress' => $macaddress,
					   
					   'created_at' => $created_at);
		    	$this->model_data->insert_data_mobile($data);
		    	
		    	$info= array(
		    		   'status' => 'Success',
		    		   'ket'	=> 'Attended',
		    		);
		    	$this->response($info,200);
	    	}
	    }

	    public function absen_post2(){
	    	//$data= (array)json_decode(file_get_contents('php://input'));

	    	
	    	$nama  	    	= $this->post('nama');
		    $finger_id  	= $this->post('finger_id');
		    $tag_date 		= $this->post('tag_date');
		    $finger_ip	   	= $this->post('finger_ip');
		  	
		    	    
			if ($nama=='' or $finger_id=='' or $tag_date=='' or $finger_ip=='') {
	    		$data = array('status' => 'error' , 'ket' => 'Please complete the parameter' );
	    		$this->response($data,200);
	    	}else{
				$data=array(
					   'nama'        => $nama,
					   'finger_id'   => $fingerId,
					   'tag_date'  => $tag_date,
					   'finger_ip'	    => $ip);
					   					   
					   	$this->model_data->insert_data_finger($data);
		    			$info= array(
		    		   'status' => 'Success',
		    		   'ket'	=> 'Attended');
		    	$this->response($info,200);
	    	}
	    }

	    public function uppic_post()
        {
        		$nip  	    					= $this->input->post('nip');
        		$tanggal						= date('YmdHis');
          		$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'jpg|png|JPG|PNG';
                $config['max_size']             = 500;
                $config['file_name']            = $nip.$tanggal;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('photo'))
                {
                        $info = array('error' => $this->upload->display_errors());
                       	$this->response($info,404);
                }
                else
                {
                		$info=  array('status' 	   => 'success',
						    		  'ket'	   	   => 'uploaded',
						    		  'directory'  => base_url()."uploads/".$this->upload->data('file_name'));
                        
                        $this->response($info,200);
                       
                }
        }
		
		//for pegawai
        public function absenpeg_get(){
	    	$nip		=$this->get('nip');
	    	$tgl_awal	=$this->get('tgs');
	    	$tgl_akhir	=$this->get('tge');
	    	$offset		=$this->get('offset');
	    	$limit		=$this->get('limit');
	    	if (is_null($nip) or is_null($tgl_awal) or is_null($tgl_akhir)) {
	    		$data = array('status' => 'error' , 'data' => 'null' );
	    		$this->response($data,200);
	    	}else{
	    		date_default_timezone_set('Asia/Jakarta');
		    	$data = array(
		    			  'presensi'=>
		    				array(
				    			'data_absensi_mobile' 	   => $this->model_data->absPegawaiMobile($nip,$tgl_awal,$tgl_akhir,$offset,$limit),
				    			'data_absensi_finger'      => $this->model_data->absPegawaiFinger($nip,$tgl_awal,$tgl_akhir,$offset,$limit),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
		    	$this->response($data,200);
	    	}
	    }
		
		//for pegawai unit
		
        public function absenpegunit_get(){
	    	$tgl_awal	=$this->get('tgs');
	    	$tgl_akhir	=$this->get('tge');
	    	$offset		=$this->get('offset');
	    	$limit		=$this->get('limit');
	    	if (is_null($tgl_awal) or is_null($tgl_akhir)) {
	    		$data = array('status' => 'error' , 'data' => 'null' );
	    		$this->response($data,200);
	    	}else{
	    		date_default_timezone_set('Asia/Jakarta');
		    	$data = array(
		    			  'presensi'=>
		    				array(
				    			'data_absensi_mobile' 	   => $this->model_data->absPegawaiMobileUnit($tgl_awal,$tgl_akhir,$offset,$limit),
				    			'data_absensi_finger'      => $this->model_data->absPegawaiFingerUnit($tgl_awal,$tgl_akhir,$offset,$limit),
				    			'latest_update' 		   => date('Y-m-d H:i:s')));
		    	$this->response($data,200);
	    	}
	    }
		

	    //insert sanggah ke tabel penampung

	    public function sanggah_post(){
	    	$id 			= $this->post('id');
		    $nip  			= $this->post('nip');
		    $presensi_ke 	= $this->post('presensi_ke');
		    $tag_date	   	= $this->post('tag_date');
		    $ket 			= $this->post('ket');
         	$status         = $this->post('status');
                    
		    if ($nip=="" or $presensi_ke=="" or $tag_date=="" or $ket=="") {
		    	$data = array('status' => false , 'ket' => 'empty parameter' );
	    		$this->response($data,200);
		    }else{
		    	$data = array(
		    				  'id'	        =>  $id,
		    				  'nip'			=>	$nip,
		    				  'presensi_ke'	=>	$presensi_ke,
		    				  'tag_date'	=>	$tag_date,
		    				  'ket'			=>	$ket,
		    				//'status' => $status
		    				  );
		    	$this->model_data->insert_data_sanggah($data);
		    	$data = array('status' => true, 'ket' => 'data ditambahkan!' );
	    		$this->response($data,200);
		    }
	    }

	    //get sanggah
	     public function sanggah_get(){
	    		$nip = $this->get('nip');
	    		
	    		if (is_null($nip)){
	    			$data = array('status' => 'error' , 'data' => 'null' );
	    			$this->response($data,200);
	    		} else{
	    		date_default_timezone_set('Asia/Jakarta');
	    		$data = array(
	    			'nip' => $nip,
	    			'sanggah' => $this->model_data->sanggahAbs($nip)	
	    		);
	    		$this->response($data,200);
	    			
	    		}
	    }	 

	    //get reasi
	    // public function relasi_get(){
	    // 	header('Content-Type: application/json');
	    // 	$tgl_awal	=$this->get('tgs');
	    // 	$tgl_akhir	=$this->get('tge');
	    // 	if (is_null($tgl_awal) or is_null($tgl_akhir)) {
	    // 		$data = array('status' => 'error' , 'data' => 'null' );
	    // 		$this->response($data,200);
	    // 	}else{
	    // 		date_default_timezone_set('Asia/Jakarta');
		   //  	$data = array(
		   //  			  'relasi_data'=>
		   //  				array(
				 //    			'data_relasi' 	   => $this->model_data->relasi_data_finger($tgl_awal,$tgl_akhir),
				 //    			'latest_update' 		   => date('Y-m-d H:i:s')));
		   //  	$this->response($data,200);
		   //  	echo json_encode($data, JSON_PRETTY_PRINT);
	    // 	}
	    // }   

	     //get reasi
	    public function relasi_get(){
	    	header('Content-Type: application/json');
	    	date_default_timezone_set('Asia/Jakarta');
		    	$data = array(
		    			  'relasi_data'=>
		    				array(
				    			'data_relasi' 	   => $this->model_data->relasi_data_finger(),
				    			'latest_update'    => date('Y-m-d H:i:s')));
		    	$this->response($data,200);
		    	echo json_encode($data, JSON_PRETTY_PRINT);
	    	
	    }
	   //get api sia untuk nip pegawai
	    function api_sia_get(){ 
	    	//header('Content-Type: application/json');
	    	$nip 		=$this->get('nip');
	    	$parameter=array(
			    "api_kode" 		=>3101,
			    "api_subkode"	=>1,
			    "nip"			=>$nip
			);
			$url   ="http://service2.uin-suka.ac.id/servsimpeg/index.php/simpeg_public/simpeg_master/data_view";
			$hasil1=json_decode($this->api_sia_get($url,'POST',$parameter),true); 
 			$CI    =& get_instance();
 			$hasil = null;
 			$CI->load->library('curl'); 
 			$CI->curl->option('HTTPHEADER', array('HeaderName: adi'));
 			if ($postorget == 'POST'){
 				$hasil = $CI->curl->simple_post($api_url,$parameter);
 			} else {
 				$hasil = $CI->curl->simple_get($api_url);
 			}
 		return $hasil;
	 }	    
}