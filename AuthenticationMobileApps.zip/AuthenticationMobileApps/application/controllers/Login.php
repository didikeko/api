<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct(){
			parent::__construct();
			if (isset($_SESSION['login'])) {
				header("location: /presensi/menu");
			}
			$this->load->model('presensimodel');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$log['error']="";
		$this->load->view('login_form',$log);
	}
	public function auth(){
		$data['username']=$this->input->post('username');
		$data['password']=$this->input->post('password');
		if ($data['username']=='' or $data['password']=='') {
			$log['error']="null field";
			$this->load->view('login_form',$log);
		}else{
			$url="http://ios.pdef.space/auth.php";
			$result=$this->presensimodel->postcURL($url,$data);
			if ($result->status==true) {
				echo $result->message.", redirecting...";
				$user = array('login'=> true,
							  'nip'  => $result->auth->nip,
							  'nama' => $result->auth->nama_lengkap,
							  'level'=> $result->auth->level
				);
				$this->session->set_userdata($user);
				echo "<script>window.setTimeout(function(){ window.location = '/".base_url("menu")."'; },3000);</script>";
			}else{
				echo $result->message;
			}
		}
		
	}
	public function logout(){
		$this->session->sess_destroy();
		header("location: /presensi/login");

	}
}
